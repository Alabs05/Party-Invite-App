import React, {useLayoutEffect, useState} from 'react';
import AddToList from '../components/AddToList';
import People from '../components/People';
import './app.scss'

export interface IState {
  people: {
      name: string
      age: number
      url: string
      note?: string
  }[]
}

function App() {
  const [people, setPeople] = useState<IState["people"]>([
    {
      name: "Tate",
      url: "https://i.im.ge/2022/10/07/1vQY74.tate.jpg",
      age: 35,
      note: "Click the add to list button below"

    }
  ]);
  const [openModal, setOpenModal] = useState(false);


  const toClose = () => {
    return setOpenModal(false);
  }

  return (
    <div className="app">
      <p>People Invited to my Party</p>
      <People people={people}/>
      <button id="plus" onClick={() => setOpenModal(true)}>+  Add to List</button>
      {openModal && <AddToList open={openModal} onClose={toClose} people={people} setPeople={setPeople} />}
    </div>
  );
}

export default App;
