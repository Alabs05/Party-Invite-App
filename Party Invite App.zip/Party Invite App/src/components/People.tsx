import React, { useState, useLayoutEffect } from 'react';
import { IState as IProps } from '../app/App';


const People: React.FC<IProps> = ({ people }) => {

    const renderList = (): JSX.Element[] => {
        return people.map((person) => {
            return (
                <li className="people_list">
                    <div className="people_list_Top">
                        <div className="people_list_Top_Left">
                            <img src={person.url} alt="" />
                            <p id="name">{person.name}</p>
                        </div>
                        <div className="people_list_Top_Right">
                            <h5>{person.age} years old</h5>
                        </div>
                    </div>
                    <h6>{person.note}</h6>
                </li>
            )
        })
    }

    
  return (
    <div className="people">
        {renderList()}
    </div>
  )
}

export default People;