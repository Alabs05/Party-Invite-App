import React, { useState } from 'react';
import { IState as Peo_Props } from '../app/App';

interface AProps {
    open: boolean | string
    onClose?: any | boolean
    people: Peo_Props["people"]
    setPeople: React.Dispatch<React.SetStateAction<Peo_Props["people"]>>
}   

const AddToList: React.FC<AProps> = ({ open, onClose, people, setPeople }) => {

    const [input, setInput] = useState({
        name: "",
        age: "",
        img: "",
        note: ""
    })

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>): void => {
        setInput({
            ...input,
            [e.target.name]: e.target.value
        })
    }

    const handleClick = (): void => {
        if(
            !input.name ||
            !input.age ||
            !input.img
        ) { return }

        setPeople([
            ...people,
            {
                name: input.name,
                age: parseInt(input.age),
                url: input.img,
                note: input.note
            }
        ]);
        setInput({
            name: "",
            age: "",
            img: "",
            note: ""
        });
 
    }

  return (
    <div className="addToList">
        <p onClick={onClose}>X</p>
        <h5>Name</h5>
        <input 
            type="text" 
            className="addToList_input"
            value={input.name}
            onChange={handleChange}
            name="name"
            required
        />
        <h5>Age</h5>
        <input 
            type="number" 
            className="addToList_input"
            value={input.age}
            onChange={handleChange}
            name="age"
            required
        />
        <h5>Image URL</h5>
        <input 
            type="text" 
            className="addToList_inputUrl"
            onChange={handleChange}
            value={input.img}
            name="img"
            required
        />
        <h5>Note</h5>
        <textarea 
            className="addToList_inputArea"
            value={input.note}
            name="note"
            onChange={handleChange} 
            
        />
        <button 
            className="Done_btn"
            onClick={handleClick} 
            type="submit"
        >
            <span onClick={onClose}>Done</span>
        </button>
    </div>
  )
}

export default AddToList;